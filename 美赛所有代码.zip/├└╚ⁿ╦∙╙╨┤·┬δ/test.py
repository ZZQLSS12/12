import pandas as pd
import numpy as np


def topsis(normalized_matrix, weights):
    ideal_positive = np.max(normalized_matrix, axis=0)
    ideal_negative = np.min(normalized_matrix, axis=0)


    distance_positive = np.sqrt(np.sum(weights * (ideal_positive-normalized_matrix) ** 2, axis=1))
    distance_negative = np.sqrt(np.sum(weights * (ideal_negative-normalized_matrix) ** 2, axis=1))
    topsis_scores = distance_negative / (distance_positive + distance_negative)
    return topsis_scores


def my_write2(name1,x1,name2,x2):
    # 将两列数据组合成一个 DataFrame
    data = {name1: x1,name2:x2}
    df_new = pd.DataFrame(data)

    # 指定新Excel文件的路径
    new_excel_file_path = r"D:\桌面\result.xlsx"

    # 使用 to_excel 方法将数据写入新的Excel文件
    df_new.to_excel(new_excel_file_path, index=False)

    print(f"数据已成功写入新的Excel文件: {new_excel_file_path}")


df = pd.read_excel(r"C:\Users\lenovo\Downloads\优劣解距离法(TOPSIS) (1).xlsx")

# weights = pd.read_excel(r"D:\桌面\weight.xlsx")['连续'].to_list()
# weight = np.array(weights)
weights = np.array([0.258,0.227,0.257,0.258])


column_labels = df.columns.to_numpy()

data = []

for label in column_labels:
    data.append(df[label].to_list())

data=data[1:]
Data = np.array(data).astype(float)

#p1
# 对于正向指标
for i in range(0,2):
    x_min = np.min(Data[i]) - 0.0001
    x_max = np.max(Data[i]) + 0.0001
    min_max_normalized = (Data[i] - x_min) / (x_max - x_min)
    Data[i]= min_max_normalized
# 对于负向指标
for i in range(2,len(Data)):
    x_min = np.min(Data[i]) - 0.0001
    x_max = np.max(Data[i]) + 0.0001
    min_max_normalized = (x_max - Data[i]) / (x_max - x_min)
    Data[i] = min_max_normalized

data1 = np.array(list(zip(*(Data.tolist()))))

scores1 = topsis(data1, weights)

# Data = np.array(data)
#
# # p2
# # 对于正向指标
# for i in range(1, len(Data), 2):
#     x_min = np.min(Data[i]) - 0.0001
#     x_max = np.max(Data[i]) + 0.0001
#     min_max_normalized = (Data[i] - x_min) / (x_max - x_min)
#     Data[i] = min_max_normalized
# # 对于负向指标
# for i in range(0, len(Data), 2):
#     x_min = np.min(Data[i]) - 0.0001
#     x_max = np.max(Data[i]) + 0.0001
#     min_max_normalized = (x_max - Data[i]) / (x_max - x_min)
#     Data[i] = min_max_normalized
#
# data2 = np.array(list(zip(*(Data.tolist()))))
#
# for i in range(0,len(weights),2):
#     weights[i],weights[i+1] = weights[i+1],weights[i]
# scores2 = topsis(data2, weights)
#
# my_write2('Force1', scores1,'Force2',scores2)

# 权重
