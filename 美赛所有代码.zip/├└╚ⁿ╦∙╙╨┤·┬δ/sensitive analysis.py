import pandas as pd
import numpy as np
from tqdm import trange
import matplotlib as mpl

df = pd.read_excel(r"D:\桌面\1701.xlsx")

lianxv1 = df['1连续'].to_numpy()
lianxv2 = df['2连续'].to_numpy()
lisan1 = df['1离散'].to_numpy()
lisan2 = df['2离散'].to_numpy()

base = 0

blank = pd.DataFrame()
M1_set=[]
M2_set=[]

upper1 = []
upper2 = []
lower1 = []
lower2 = []

for i in range(5):
    alpha = round(base+i*0.05,3)
    M1= lianxv1+alpha*lisan1
    M2 = lianxv2+alpha*lisan2
    blank[f'M1-{alpha}'] = M1
    blank[f'M2-{alpha}'] = M2
    M1_set.append(M1)
    M2_set.append(M2)



M1_set = np.array(M1_set)
M2_set = np.array(M2_set)

# array_2d = np.array([[1, 5, 3, 7, 2],
#                      [4, 8, 2, 1, 6],
#                      [9, 2, 5, 4, 7]])

# 生成新的一维数组，每个元素是所有数组在该位置的最大值
upper1 = np.amax(M1_set, axis=0)
upper2 = np.amax(M2_set, axis=0)
lower1 = np.amin(M1_set,axis=0)
lower2 = np.amin(M2_set,axis=0)

# upper1 = upper1-M1_set[2]
# upper2 = upper2 -M2_set[2]
# lower1 = M1_set[2]-lower1
# lower2 = M2_set[2]-lower2

x = [i for i in range(len(upper1))]

import matplotlib.pyplot as plt

y1= M1_set[2]
y2=upper1
y3=lower1

# # 画三条曲线
# plt.plot(x, y1, label='Curve 1',color = '#0000ff',linewidth=0.2)
# plt.plot(x, y2, label='Curve 2',color = '#0000ff',linewidth=0.2)
# plt.plot(x, y3, label='Curve 3',color = '#0000ff',linewidth=0.2)

def moving_average(data, window_size):
    return np.convolve(data, np.ones(window_size)/window_size, mode='valid')

mpl.rcParams['font.family'] = 'times new roman'

# 应用滑动平均
smoothed_y1 = moving_average(y1, 5)
smoothed_y2 = moving_average(y2, 5)
smoothed_y3 = moving_average(y3, 5)
smoothed_x = x[:-4]  # 由于滑动平均减少了数据点，需要相应调整 x 轴

# 画三条平滑处理后的曲线，并调整颜色和粗细
plt.plot(smoothed_x, smoothed_y1, label='Momentum1', color='blue', linewidth=1)
plt.plot(smoothed_x, smoothed_y2, color='blue', linewidth=0.2)
plt.plot(smoothed_x, smoothed_y3, color='blue', linewidth=0.2)

plt.fill_between(smoothed_x, smoothed_y3, smoothed_y2, color='#cbffff', alpha=0.5)

y4=M2_set[2]
y5=upper2
y6=lower2

# 应用滑动平均
smoothed_y1 = moving_average(y4, 5)
smoothed_y2 = moving_average(y5, 5)
smoothed_y3 = moving_average(y6, 5)
smoothed_x = x[:-4]  # 由于滑动平均减少了数据点，需要相应调整 x 轴

# 画三条平滑处理后的曲线，并调整颜色和粗细
plt.plot(smoothed_x, smoothed_y1, label='Momentum2', color='r', linewidth=1)
plt.plot(smoothed_x, smoothed_y2, color='red', linewidth=0.2)
plt.plot(smoothed_x, smoothed_y3, color='r', linewidth=0.2)

plt.fill_between(smoothed_x, smoothed_y3, smoothed_y2, color='#ffcbcb', alpha=0.5)

plt.xticks(fontsize=12)
plt.yticks(fontsize=12)
plt.xlabel('Points',fontsize=14)
plt.ylabel('Momentum',fontsize=14)


# 填充中间的面积
# plt.fill_between(x, y2, y3, color='#ff775c', alpha=0.5, label='Filled Area')

# 添加图例
plt.legend()

plt.savefig('fig3.png',dpi=700)

# 显示图形
plt.show()


# blank['upper1'] = upper1
# blank['lower1'] = lower1
# blank['upper2'] = upper2
# blank['lower2'] = lower2
# blank.to_excel('sensitivity analysis.xlsx')




