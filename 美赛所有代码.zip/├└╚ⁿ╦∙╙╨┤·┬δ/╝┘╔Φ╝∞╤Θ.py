import matplotlib.pyplot as plt
import numpy as np

# 创建一些示例数据
x = np.linspace(0, 10, 100)
y1 = np.sin(x)
y2 = np.cos(x)
y3 = np.sin(x) + np.cos(x)

# 画三条曲线
plt.plot(x, y1, label='Curve 1')
plt.plot(x, y2, label='Curve 2')
plt.plot(x, y3, label='Curve 3')

# 填充中间的面积
plt.fill_between(x, y1, y2, color='gray', alpha=0.5, label='Filled Area')

# 添加图例
plt.legend()

# 显示图形
plt.show()
