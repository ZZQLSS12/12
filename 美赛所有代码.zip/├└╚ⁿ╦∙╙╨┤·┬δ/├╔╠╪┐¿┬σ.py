import numpy as np
import pandas as pd
from tqdm import trange
id = 1304

df= pd.read_excel(rf"D:\桌面\每场比赛\2023-wimbledon-{id}_t_subset.xlsx")

point_victor = df['point_victor'].to_numpy()
server = df['server'].to_numpy()

fa1=0
fa2=0

for it in server:
    if it==1:
        fa1+=1
    else:
        fa2+=1

total=fa1+fa2

win1=0
win2=0
winfa1=0
winfa2=0

for i in range(len(server)):
    if point_victor[i]==1:
        win1+=1
        if server[i]==1:
            winfa1+=1
    else:
        win2+=1
        if server[i]==2:
            winfa2+=1

prob_fa1=winfa1/fa1
prob_fa2=winfa2/fa2
# print(prob_fa1)
# print(prob_fa2)
print('_____________________________')

def my_write(name,x):
    # 将两列数据组合成一个 DataFrame
    data = {name: x}
    df_new = pd.DataFrame(data)

    # 指定新Excel文件的路径
    new_excel_file_path = r"result.xlsx"

    # 使用 to_excel 方法将数据写入新的Excel文件
    df_new.to_excel(new_excel_file_path, index=False)

    print(f"数据已成功写入新的Excel文件: {new_excel_file_path}")

def Monte():
    moni=[]
    for i in range(len(server)):
        if server[i]==1:
            random_number = np.random.rand()

            if random_number<=prob_fa1:
                moni.append(1)
            else:
                moni.append(2)
        else:
            random_number = np.random.rand()
            if random_number<=prob_fa2:
                moni.append(2)
            else:
                moni.append(1)
    return moni

def get_liansheng(moni):
    lian=[]
    p1_temp = 0
    p2_temp = 0
    for i in range(0, len(moni)):



        if p1_temp != 0:
            lian.append(p1_temp)
        else:
            lian.append(-1 * p2_temp)

        if moni[i] == 1:
            p2_temp = 0
            p1_temp += 1
        else:
            p1_temp = 0
            p2_temp += 1
    return lian

def jianyan(lian,id):

    type=1
    excel_file_path = rf"D:\桌面\动能\Force_{id}.xlsx"
    df1 = pd.read_excel(excel_file_path)

    yl = df1[f'Force{type}'].to_numpy()
    yll = df1['Force2'].to_numpy()

    y_means = np.mean(yl)

    high=[]

    # for i in range(len(yl)):
    #     if yl[i]>yll[i]:
    #         high.append(i)

    for i in range(len(yl)):
        if yl[i]>y_means:
            high.append(i)

    lian_high=0
    lian_total=0

    for index, item in enumerate(lian):
        if item>=2:
            lian_total+=1
            if np.isin(index-1,high):
                lian_high+=1

    df3 = pd.read_excel(rf"D:\桌面\每场比赛\2023-wimbledon-{id}_t_subset.xlsx")

    vic = df3['point_victor'].to_numpy()

    vic_high = 0
    vic_total=0
    for index, item in enumerate(vic):
        if item==type:
            vic_total+=1
            if np.isin(index-1,high):
                vic_high+=1

    ans1=lian_high/vic_high
    ans2=lian_total/vic_total
    # print(ans1)
    # print(ans2)
    return ans1-ans2


result=[]
for i in trange(500):
    moni = Monte()
    lian = get_liansheng(moni)
    result.append(jianyan(lian,id))

my_write('差值',result)













