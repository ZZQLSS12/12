import random

from deap import base
from deap import creator
from deap import tools

IND_SIZE = 5

creator.create("FitnessMin", base.Fitness, weights=(-1.0, -1.0))
creator.create("Individual", list, fitness=creator.FitnessMin)

toolbox = base.Toolbox()

def generate_random_bit():
    return random.choice([0, 1])

toolbox.register("attr_bit", generate_random_bit)
toolbox.register("individual", tools.initRepeat, creator.Individual,
                 toolbox.attr_bit, n=4)

ind1 = toolbox.individual()
ind2 = toolbox.individual()
child1, child2 = [toolbox.clone(ind) for ind in (ind1, ind2)]
tools.cxBlend(child1, child2, 0.5)

print(ind1)
print(ind2)
print(child1)
print(child2)