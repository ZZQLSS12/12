import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import matplotlib as mpl

swing = []
pos = []
neg = []

swing_sum=0
swing_teshu = 0

def swing_split(id,type):
    global swing_sum,swing_teshu
    df = pd.read_excel(rf"D:\桌面\动能\Force_{id}.xlsx")

    Force = df['Force1'].to_numpy()
    if type ==1:
        Force = df['Force1'].to_numpy()
    else:
        Force = df['Force2'].to_numpy()

    df1 = pd.read_excel(rf"D:\桌面\每场比赛\2023-wimbledon-{id}_t_subset.xlsx")

    game_no = df1['game_no'].to_numpy()
    ace1 = df1['p1_ace'].to_numpy()
    ace2=df1['p2_ace'].to_numpy()
    break1 = df1['p1_break_pt_won'].to_numpy()
    break2 = df1['p2_break_pt_won'].to_numpy()
    fault1 = df1['p1_double_fault'].to_numpy()
    fault2 = df1['p2_double_fault'].to_numpy()
    winner1 = df1['p1_winner'].to_numpy()
    winner2 = df1['p2_winner'].to_numpy()

    diff = []
    d = 1
    for i in range(0, len(Force)-d):
        diff.append(Force[i+d] - Force[i])

    means = np.mean(diff)
    std = np.std(diff)


    # 正/负/总波动
    pos_index_set = []
    neg_index_set = []
    swing_set = []

    sigma = 1
    for index, item in enumerate(diff):
        if np.abs(item - means) > sigma * std:
            # swing_set.append(index)
            # if item - means > 0:
            #     pos_index_set.append(index)
            # else:
            #     neg_index_set.append(index)
            swing_sum += 1
            if ace1[index] or ace2[index] or break1[index] or break2[index] or fault1[index] or fault2[index] or \
                    winner1[index] or winner2[index]:
                swing_teshu += 1

    # begin = []
    # for i in range(len(game_no)):
    #     if game_no[i] != game_no[i - 1]:
    #         begin.append(i)
    # begin.append(len(game_no))
    # gap = 1
    # print(len(begin) - gap - 1)
    # for i in range(1,len(begin) - gap,gap):
    #
    #     pos_temp = 0
    #     neg_temp = 0
    #     swing_temp = 0
    #
    #
    #     for item in pos_index_set:
    #         if begin[i] <= item < begin[i + gap]:
    #             pos_temp += 1
    #     for item in swing_set:
    #         if begin[i] <= item < begin[i + gap]:
    #             swing_temp += 1
    #     for item in neg_index_set:
    #         if begin[i] <= item < begin[i + gap]:
    #             neg_temp += 1
    #
    #     pos.append(pos_temp)
    #     neg.append(neg_temp)
    #     swing.append(swing_temp)


def draw(diff, swing_set):
    x = list(range(len(diff)))

    fig, ax = plt.subplots()

    # 绘制折线图
    ax.plot(x, diff, label='Force1')

    special_points_x = swing_set
    special_points_y = []
    for i in range(len(special_points_x)):
        special_points_y.append(diff[special_points_x[i]])
    plt.scatter(special_points_x, special_points_y, color='red', label='swing-dot')

    ax.legend(loc='lower right')
    # plt.savefig('fig1.png',dpi=500)
    plt.show()


id_set = []
a = [13, 14, 15, 16, 17]
for item in a:
    for i in range(1, 2 ** (17 - item) + 1):
        if i < 10:
            temp = str(item) + '0' + str(i)
            id_set.append(temp)
        else:
            temp = str(item) + str(i)
            id_set.append(temp)

for id in id_set:
    swing_split(id,1)
    swing_split(id,2)

print(swing_teshu/swing_sum)

# swing_split('')


# data = {'正波动': pos, '负波动': neg, '总波动': swing}
# df_new = pd.DataFrame(data)
#
# # 指定新Excel文件的路径
# new_excel_file_path = rf"swing.xlsx"
#
# # 使用 to_excel 方法将数据写入新的Excel文件
# df_new.to_excel(new_excel_file_path, index=False)
#
# print(f"数据已成功写入新的Excel文件: {new_excel_file_path}")
