import numpy as np
from statsmodels.sandbox.stats.runs import runstest_1samp

def is_random(sequence, num_simulations=1000):
    observed_statistic = runstest_1samp(sequence)[0]

    # 生成随机序列并计算检测指标
    random_statistics = [runstest_1samp(np.random.choice([0, 1], size=len(sequence)))[0] for _ in range(num_simulations)]

    # 基准分布
    baseline_distribution = np.array(random_statistics)

    # 检测实际序列在基准分布中的位置
    p_value = (np.abs(observed_statistic) > np.mean(abs(baseline_distribution)))

    return p_value

# 示例：生成一个随机序列
random_sequence = np.random.choice([0, 1], size=100)

# 检测序列是否随机
p_value = is_random(random_sequence)
print("P-value for randomness:", p_value)
