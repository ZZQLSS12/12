import pandas as pd
import numpy as np
from statsmodels.sandbox.stats.runs import runstest_1samp

l1 = []
l2 = []
l3 = []
dataframe = pd.DataFrame()


def my_write2(name1, x1, name2, x2):
    # 将两列数据组合成一个 DataFrame
    data = {name1: x1, name2: x2}
    df_new = pd.DataFrame(data)

    # 指定新Excel文件的路径
    new_excel_file_path = r"result.xlsx"

    # 使用 to_excel 方法将数据写入新的Excel文件
    df_new.to_excel(new_excel_file_path, index=False)

    print(f"数据已成功写入新的Excel文件: {new_excel_file_path}")


def jiancha(id, type):
    global dataframe
    df = pd.read_excel(rf"D:\桌面\每场比赛\2023-wimbledon-{id}_t_subset.xlsx")

    set_no = df['set_no'].to_numpy()
    game_no = df['game_no'].to_numpy()
    game_victor = df['game_victor'].to_numpy()

    game_beg = []
    game_win = []

    game_beg.append(0)
    for i in range(len(game_victor)):
        if game_victor[i] > game_victor[i - 1]:
            game_beg.append(i)
            if i != 0 and game_victor[i] != 0:
                game_win.append(game_victor[i])
    # print(game_beg)
    # print(game_win)
    #
    # print(len(game_beg))
    # print(len(game_win))

    df1 = pd.read_excel(rf"D:\桌面\动能\Force_{id}.xlsx")
    force = df1[f'Force{type}'].to_numpy()

    force_mean = np.mean(force)

    high = []

    for i in range(len(game_beg) - 1):
        mean_f = np.mean(force[game_beg[i]:game_beg[i + 1]])
        if mean_f >= force_mean:
            high.append(i)

    def get_liansheng(moni):
        lian = []
        p1_temp = 0
        p2_temp = 0
        for i in range(0, len(moni)):

            if p1_temp != 0:
                lian.append(p1_temp)
            else:
                lian.append(-1 * p2_temp)

            if moni[i] == 1:
                p2_temp = 0
                p1_temp += 1
            else:
                p1_temp = 0
                p2_temp += 1

        return np.array(lian)

    lian = get_liansheng(game_win)
    if type == 2:
        lian = -lian

    lian_high = 0
    lian_total = 0
    win_high = 0
    win_total = 0

    for i in range(len(lian)):
        if lian[i] >= 2:
            lian_total += 1
            if np.isin(i, high):
                lian_high += 1

    for i in range(len(game_win)):
        if game_win[i] == type:
            win_total += 1
            if np.isin(i, high):
                win_high += 1

    rate1 = lian_high / win_high
    rate2 = lian_total / win_total

    l1.append(rate1)
    l2.append(rate2)
    if lian_total == 0:
        l3.append(10)
    else:
        l3.append(lian_high / lian_total)


def win_list(id):
    global dataframe
    df = pd.read_excel(rf"D:\桌面\每场比赛\2023-wimbledon-{id}_t_subset.xlsx")

    set_no = df['set_no'].to_numpy()
    game_no = df['game_no'].to_numpy()
    game_victor = df['game_victor'].to_numpy()

    game_beg = []
    game_win = []

    game_beg.append(0)
    for i in range(len(game_victor)):
        if game_victor[i] > game_victor[i - 1]:
            game_beg.append(i)
            if i != 0 and game_victor[i] != 0:
                game_win.append(game_victor[i])

    return game_win


id_set = []

a = [13, 14, 15, 16, 17]
for item in a:
    for i in range(1, 2 ** (17 - item) + 1):
        if i < 10:
            temp = str(item) + '0' + str(i)
            id_set.append(temp)
        else:
            temp = str(item) + str(i)
            id_set.append(temp)

count1 = 0
count2 = 0
# for id in id_set:
#
#     # 检验games胜利情况分布
#     result1 = runstest_1samp(win_list(id))
#     # 检验points胜利情况分布
#     result2 = runstest_1samp(pd.read_excel(rf"D:\桌面\每场比赛\2023-wimbledon-{id}_t_subset.xlsx")['point_victor'].to_numpy())
#     if result1[1]<0.05:
#         count1+=1
#     if result2[i]<0.05:
#         count2+=1
# print(count1/len(id_set))
# # 0.6774193548387096
# print(count2/len(id_set))
# # 0.16129032258064516

for id in id_set:
    jiancha(id, 1)
    jiancha(id, 2)

# win_list('1501')
# new_excel_file_path = r"result.xlsx"
# 使用 to_excel 方法将数据写入新的Excel文件
# dataframe.to_excel(new_excel_file_path, index=False)
my_write2('高势头连胜次数/高势头胜球数', l1, '高势头连胜/总连胜', l2)
