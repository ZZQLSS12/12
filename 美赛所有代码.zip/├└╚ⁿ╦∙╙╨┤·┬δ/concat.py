import pandas as pd

id_set=[]

a = [13,14,15,16,17]
for item in a:
    for i in range(1,2**(17-item)+1):
        if i<10:
            temp = str(item)+'0'+str(i)
            id_set.append(temp)
        else:
            temp = str(item)+str(i)
            id_set.append(temp)

df_set=[]
for id in id_set:
    df_set.append(pd.read_excel(rf"D:\桌面\动能\Force_{id}.xlsx"))

result = pd.concat(df_set, ignore_index=True)
result.to_excel('concat_result.xlsx')