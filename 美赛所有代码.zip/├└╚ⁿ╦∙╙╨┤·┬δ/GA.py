from deap import base, creator, tools
import random

# 创建适应度类
creator.create("FitnessMin", base.Fitness, weights=(-1.0,))

# 创建个体类，长度为n
n = 10  # 假设个体长度为10
creator.create("Individual", list, fitness=creator.FitnessMin)

# 创建DEAP工具箱
toolbox = base.Toolbox()

# 注册初始化函数
toolbox.register("attr_bit", random.randint, 0, 1)
toolbox.register("individual", tools.initRepeat, creator.Individual, toolbox.attr_bit, n=n)
toolbox.register("population", tools.initRepeat, list, toolbox.individual)

# 注册交叉操作函数
toolbox.register("mate", tools.cxOrdered)

# 使用工具箱创建两个个体
parent1 = toolbox.individual()
parent2 = toolbox.individual()

# 输出原始个体
print("Parent 1:", parent1)
print("Parent 2:", parent2)

# 进行交叉操作
toolbox.mate(parent1, parent2)

# 输出交叉后的个体
print("\nOffspring after Crossover:")
print("Offspring 1:", parent1)
print("Offspring 2:", parent2)
