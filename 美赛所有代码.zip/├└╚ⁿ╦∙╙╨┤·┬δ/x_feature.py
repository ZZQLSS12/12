import pandas as pd
import numpy as np

runway_l=[]
speed_l=[]
rally_count_l=[]
score_l=[]

force_l=[]
swing_l=[]

break_rate_l=[]
ace_rate_l=[]
score_rate_l=[]

def feture_extract(id):

    df1=pd.read_excel(rf"D:\桌面\每场比赛(处理后)\2023-wimbledon-{id}_t_subset.xlsx")

    game_no = df1['Q8-game_no'].to_numpy()
    run = df1['Q43-p2_distance_run'].to_numpy()
    speed = df1['Q2-speed_mph_缺失值处理'].to_numpy()
    rally = df1['Q1-rally_count_异常值处理'].to_numpy()
    score = df1['Q20-p2_points_won'].to_numpy()

    df = pd.read_excel(rf"D:\桌面\动能\Force_{id}.xlsx")
    Force2 = df['Force2'].to_numpy()

    df2=pd.read_excel(rf"D:\桌面\每场比赛(连续)\2023-wimbledon-{id}_subset.xlsx")
    Break = df2['p2破发球率'].to_numpy()
    ace = df2['p2ace率'].to_numpy()
    score_rate=df2['score_rate2'].to_numpy()

    df3=pd.read_excel(r'swing.xlsx')
    swing = df3['总波动']

    begin = []
    # begin.append(0)
    for i in range(len(game_no)):
        if game_no[i] != game_no[i - 1]:
            begin.append(i)
    begin.append(len(game_no))

    print(len(begin)-2)
    for i in range(0,len(begin)-2):
        runway_l.append(np.mean(run[begin[i]:begin[i+1]]))
        speed_l.append(np.mean(speed[begin[i]:begin[i+1]]))
        rally_count_l.append(np.mean(rally[begin[i]:begin[i+1]]))
        count=0
        for j in range(begin[i],begin[i+1]):
            if score[j]==2:
                count+=1
        score_l.append(count)
        force_l.append(Force2[begin[i+1]])
        # swing_l.append(swing)
        break_rate_l.append(Break[begin[i+1]])
        ace_rate_l.append(ace[begin[i+1]])
        score_rate_l.append(score_rate[begin[i+1]])

id_set = []
a = [13, 14, 15, 16, 17]
for item in a:
    for i in range(1, 2 ** (17 - item) + 1):
        if i < 10:
            temp = str(item) + '0' + str(i)
            id_set.append(temp)
        else:
            temp = str(item) + str(i)
            id_set.append(temp)

for id in id_set:
    feture_extract(id)

data = {'distance':runway_l,'speed':speed_l,'rally':rally_count_l,'score':score_l,'force':force_l,'break':break_rate_l,
        'ace':ace_rate_l,'score_rate':score_rate_l}

df_new = pd.DataFrame(data)

# 指定新Excel文件的路径
new_excel_file_path = rf"feature.xlsx"

# 使用 to_excel 方法将数据写入新的Excel文件
df_new.to_excel(new_excel_file_path, index=False)

print(f"数据已成功写入新的Excel文件: {new_excel_file_path}")
