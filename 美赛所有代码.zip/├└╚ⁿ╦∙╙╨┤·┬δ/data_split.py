import pandas as pd

# 指定Excel文件路径
excel_file_path = r"D:\桌面\版本2_异常值替换为平均值_Problem_C_Wimbledon_featured_matches_副本1 (1).xlsx"

# 使用Pandas的read_excel函数读取Excel文件
df = pd.read_excel(excel_file_path)

# 获取第一列的唯一值
unique_values = df.iloc[:, 2].unique()

# 根据第一列的唯一值进行拆分
for value in unique_values:
    subset = df[df.iloc[:, 2] == value]

    # 将子表格写入新的Excel文件
    subset.to_excel(rf'D:\桌面\每场比赛(处理后)\{value}_t_subset.xlsx', index=False)

print("拆分完成")
