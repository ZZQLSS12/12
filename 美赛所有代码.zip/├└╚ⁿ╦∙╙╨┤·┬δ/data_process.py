import pandas as pd

def my_write(name,x):
    # 将两列数据组合成一个 DataFrame
    data = {name: x}
    df_new = pd.DataFrame(data)

    # 指定新Excel文件的路径
    new_excel_file_path = r"D:\桌面\result.xlsx"

    # 使用 to_excel 方法将数据写入新的Excel文件
    df_new.to_excel(new_excel_file_path, index=False)

    print(f"数据已成功写入新的Excel文件: {new_excel_file_path}")

def my_write2(name1,x1,name2,x2):
    # 将两列数据组合成一个 DataFrame
    data = {name1: x1,name2:x2}
    df_new = pd.DataFrame(data)

    # 指定新Excel文件的路径
    new_excel_file_path = r"D:\桌面\result.xlsx"

    # 使用 to_excel 方法将数据写入新的Excel文件
    df_new.to_excel(new_excel_file_path, index=False)

    print(f"数据已成功写入新的Excel文件: {new_excel_file_path}")


excel_file_path = r"D:\桌面\第一问的数据.xlsx"
df = pd.read_excel(excel_file_path)




# score1 = df['p1_score'].tolist()
# score2 = df['p2_score'].tolist()
# vic = df['point_victor'].tolist()
#
# point1=[]
# point2=[]
#
# game_beg=[]
#
# for i in range(len(score1)):
#     if score1[i]==0 and score2[i]==0:
#         game_beg.append(i)
#
# game_beg.append(len(score1))

# 转化成球数
# for i in range(1,len(game_beg)):
#     b = game_beg[i-1]
#     e=game_beg[i]
#
#     p1_temp=0
#     p2_temp = 0
#
#     point1.append(0)
#     point2.append(0)
#     for j in range(b+1,e):
#         if vic[j-1]==1:
#             p1_temp+=1
#         else:
#             p2_temp+=1
#         point1.append(p1_temp)
#         point2.append(p2_temp)


# 连续得分
# lian=[]
# for i in range(1,len(game_beg)):
#     b = game_beg[i-1]
#     e=game_beg[i]
#
#     p1_temp=0
#     p2_temp = 0
#
#     lian.append(0)
#
#     for j in range(b+1,e):
#         if vic[j-1]==1:
#             p2_temp=0
#             p1_temp+=1
#         else:
#             p1_temp=0
#             p2_temp+=1
#
#         if p1_temp!=0:
#             lian.append(p1_temp)
#         else:
#             lian.append(-1*p2_temp)
# my_write('连续得分',lian)


# 接发球得分

# server = df['server'].tolist()
# vic = df['point_victor'].tolist()
#
# jf1=[]
# jf2=[]
# for i in range(1,len(game_beg)):
#     b = game_beg[i-1]
#     e=game_beg[i]
#
#     jf1.append(0)
#     jf2.append(0)
#
#     for j in range(b+1,e):
#         if vic[j-1]== 1 and server[j-1]==2:
#             jf1.append(1)
#             jf2.append(0)
#         elif vic[j-1]==2 and server[j-1]==1:
#             jf1.append(0)
#             jf2.append(1)
#         else:
#             jf1.append(0)
#             jf2.append(0)
#
# my_write('1接发球得分',jf1)
# my_write('2接发球得分',jf2)



# 发球得分
#
# server = df['server'].tolist()
# p1_ace = df['p1_ace'].tolist()
# p2_ace = df['p2_ace'].tolist()
#
# f1=[]
# f2=[]
# for i in range(1,len(game_beg)):
#     b = game_beg[i-1]
#     e=game_beg[i]
#
#     f1.append(0)
#     f2.append(0)
#
#     for j in range(b+1,e):
#         if p1_ace[j-1]==1:
#             f1.append(1)
#             f2.append(0)
#         elif p2_ace[j-1]==1:
#             f1.append(0)
#             f2.append(1)
#         else:
#             f1.append(0)
#             f2.append(0)
#
# my_write2('1ace得分(上局)',f1,'2ace得分(上局)',f2)





# point球数差异
# point_diff = []
#
# for i in range(len(point1)):
#     point_diff.append(point1[i]-point2[i])
#
# my_write('point_diff',point_diff)

# point1 = df['point1'].tolist()
# point2 = df['point2'].tolist()
# point_diff = df['point差值'].tolist()
#


# 局点
# Ju_Dian =[]
#
# for i in range(len(point1)):
#     if point1[i]>=3 and point_diff[i]>=1:
#         Ju_Dian.append(1)
#     elif point2[i]>=3 and point_diff[i]<=-1:
#         Ju_Dian.append(-1)
#     else:
#         Ju_Dian.append(0)
#
#
# my_write('局点',Ju_Dian)

# vic = df['point_victor'].tolist()


# 盘点

# Pan_Dian1 = []
# Pan_Dian2 = []
#
# p1_games = df['p1_games'].tolist()
# p2_games = df['p2_games'].tolist()
# games_diff = df['games差值'].tolist()
#
# for i in range(len(games_diff)):
#     if p1_games[i]==6 and p2_games[i]==6:
#         Pan_Dian1.append(1)
#         Pan_Dian2.append(1)
#     elif p1_games[i]>=5 and games_diff[i]>=1:
#         Pan_Dian1.append(1)
#         Pan_Dian2.append(0)
#     elif p2_games[i]>=5 and games_diff[i]<=-1:
#         Pan_Dian1.append(0)
#         Pan_Dian2.append(1)
#     else:
#         Pan_Dian1.append(0)
#         Pan_Dian2.append(0)
#
# my_write2('1set盘点',Pan_Dian1,'2set盘点',Pan_Dian2)

# 赛点

# p1_sets = df['p1_sets'].tolist()
# p2_sets = df['p2_sets'].tolist()
#
# Sai_Dian1=[]
# Sai_Dian2=[]
#
# for i in range(len(p1_sets)):
#     if p1_sets[i]==2:
#         Sai_Dian1.append(1)
#     else:
#         Sai_Dian1.append(0)
#
#     if p2_sets[i]==2:
#         Sai_Dian2.append(1)
#     else:
#         Sai_Dian2.append(0)
#
# my_write2('1match赛点',Sai_Dian1,'2match赛点',Sai_Dian2)


# 得分率

point_no = df['point_no'].tolist()
p1_points=df['p1_points_won'].tolist()
p2_points = df['p2_points_won'].tolist()

match_beg = []

score_rate1 =[]
score_rate2=[]

for i in range(len(point_no)):
    if point_no[i]==1:
        match_beg.append(i)

match_beg.append(len(point_no))

# for i in range(1,len(match_beg)):
#
#     b = match_beg[i-1]
#     e = match_beg[i]
#
#     score_rate1.append(0)
#     score_rate2.append(0)
#
#     for j in range(b+1,e):
#
#         score_rate1.append(p1_points[j-1]/point_no[j-1])
#         score_rate2.append(p2_points[j-1]/point_no[j-1])
#
# my_write2('score_rate1',score_rate1,'score_rate2',score_rate2)

# 失误率

# err_rate1=[]
# err_rate2=[]
# p1_unf_err = df['p1_unf_err'].tolist()
# p2_unf_err = df['p2_unf_err'].tolist()
#
# for i in range(1,len(match_beg)):
#
#     err1=0
#     err2=0
#
#     b = match_beg[i-1]
#     e = match_beg[i]
#
#     err_rate1.append(0)
#     err_rate2.append(0)
#
#     for j in range(b+1,e):
#
#         if p1_unf_err[j-1]==1:
#             err1+=1
#         if p2_unf_err[j-1]==1:
#             err2+=1
#
#         err_rate1.append(err1/point_no[j-1])
#         err_rate2.append(err2/point_no[j-1])
#
# my_write2('err_rate1',err_rate1,'err_rate2',err_rate2)

# 破发率

# p1_break_pt = df['p1_break_pt'].tolist()
# p2_break_pt = df['p2_break_pt'].tolist()
# p1_break_pt_won = df['p1_break_pt_won'].tolist()
# p2_break_pt_won = df['p2_break_pt_won'].tolist()
#
# break_rate1 = []
# break_rate2 = []
#
# for i in range(1,len(match_beg)):
#
#     total_break1 = 0
#     won_break1 = 0
#     total_break2 = 0
#     won_break2 = 0
#
#
#     b=match_beg[i-1]
#     e=match_beg[i]
#
#     break_rate1.append(0)
#     break_rate2.append(0)
#
#     for j in range(b+1,e):
#
#         if p1_break_pt[j-1]==1:
#             total_break1+=1
#         if p2_break_pt[j-1]==1:
#             total_break2+=1
#
#         if p1_break_pt_won[j-1]==1:
#             won_break1+=1
#         if p2_break_pt_won[j-1]==1:
#             won_break2+=1
#
#         if total_break1==0:
#             break_rate1.append(0)
#         else:
#             break_rate1.append(won_break1/total_break1)
#
#         if total_break2==0:
#             break_rate2.append(0)
#         else:
#             break_rate2.append(won_break2/total_break2)
#
#
# my_write2('p1破发球率',break_rate1,'p2破发球率',break_rate2)

# ace率

# server = df['server'].tolist()
# p1_ace = df['p1_ace'].tolist()
# p2_ace = df['p2_ace'].tolist()
#
# ace_rate1 = []
# ace_rate2 = []
#
# for i in range(1,len(match_beg)):
#
#     server1=0
#     ace1=0
#     server2=0
#     ace2=0
#
#
#     b=match_beg[i-1]
#     e=match_beg[i]
#
#     ace_rate1.append(0)
#     ace_rate2.append(0)
#
#     for j in range(b+1,e):
#
#         if server[j-1]==1:
#             server1+=1
#         else:
#             server2+=1
#
#         if p1_ace[j-1]==1:
#             ace1+=1
#         if p2_ace[j-1]==1:
#             ace2+=1
#
#         if server1==0:
#             ace_rate1.append(0)
#         else:
#             ace_rate1.append(ace1/server1)
#         if server2==0:
#             ace_rate2.append(0)
#         else:
#             ace_rate2.append(ace2/server2)
#
#
# my_write2('p1ace率',ace_rate1,'p2ace率',ace_rate2)


# 网前得分率

# p1_net_pt = df['p1_net_pt'].tolist()
# p2_net_pt = df['p2_net_pt'].tolist()
# p1_net_pt_won = df['p1_net_pt_won'].tolist()
# p2_net_pt_won = df['p2_net_pt_won'].tolist()
#
# net_rate1 = []
# net_rate2 = []
#
# for i in range(1,len(match_beg)):
#
#     total_net1 = 0
#     won_net1 = 0
#     total_net2 = 0
#     won_net2 = 0
#
#
#     b=match_beg[i-1]
#     e=match_beg[i]
#
#     net_rate1.append(0)
#     net_rate2.append(0)
#
#     for j in range(b+1,e):
#
#         if p1_net_pt[j-1]==1:
#             total_net1+=1
#         if p2_net_pt[j-1]==1:
#             total_net2+=1
#
#         if p1_net_pt_won[j-1]==1:
#             won_net1+=1
#         if p2_net_pt_won[j-1]==1:
#             won_net2+=1
#
#         if total_net1==0:
#             net_rate1.append(0)
#         else:
#             net_rate1.append(won_net1/total_net1)
#
#         if total_net2==0:
#             net_rate2.append(0)
#         else:
#             net_rate2.append(won_net2/total_net2)
#
#
# my_write2('p1网前得分率',net_rate1,'p2网前得分率',net_rate2)

# 离散特征


p1_double_fault = df['p1_double_fault'].tolist()
p2_double_fault = df['p2_double_fault'].tolist()

p1_winner = df['p1_winner'].tolist()
p2_winner = df['p2_winner'].tolist()

p1_break_pt_won = df['p1_break_pt_won'].tolist()
p2_break_pt_won = df['p2_break_pt_won'].tolist()

p1_ace = df['p1_ace'].tolist()
p2_ace = df['p2_ace'].tolist()

p1=[]
p2=[]

for i in range(1,len(match_beg)):

    b=match_beg[i-1]
    e=match_beg[i]

    temp1=0
    temp2=0
    p1.append(0)
    p2.append(0)

    for j in range(b+1,e):

        if j-b<=3:
            temp1+=p1_ace[j-1]
            temp2+=p2_ace[j-1]
        else:
            temp1 =temp1 - p1_ace[j-4]+p1_ace[j-1]
            temp2 = temp2 -p2_ace[j-4]+p2_ace[j-1]

        p1.append(temp1)
        p2.append(temp2)

my_write2('ace1',p1,'ace2',p2)





























