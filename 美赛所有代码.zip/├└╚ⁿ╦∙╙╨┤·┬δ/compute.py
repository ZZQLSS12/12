import pandas as pd

def my_write(name,x):
    # 将两列数据组合成一个 DataFrame
    data = {name: x}
    df_new = pd.DataFrame(data)

    # 指定新Excel文件的路径
    new_excel_file_path = r"D:\桌面\result.xlsx"

    # 使用 to_excel 方法将数据写入新的Excel文件
    df_new.to_excel(new_excel_file_path, index=False)

    print(f"数据已成功写入新的Excel文件: {new_excel_file_path}")


excel_file_path = r"D:\桌面\每场比赛(连续)\2023-wimbledon-1301_subset.xlsx"
df = pd.read_excel(excel_file_path)






