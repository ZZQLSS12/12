import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import matplotlib as mpl

df = pd.read_excel(r"D:\桌面\乒乓球.xlsx")

result1 = []
result2 = []
p1 = 0
p2 = 0

point = df['胜球id'].tolist()

for i in range(len(point)):
    if point[i] == 1:
        p1 += 1
        p2 -= 1
    else:
        p2 += 1
        p1 -= 1
    result1.append(p1)
    result2.append(p2)

y1 = np.array(result1)
y2 = np.array(result2)
y1 = 0.46 + 0.76 / 12 * y1
y2 = 0.46 + 0.76 / 12 * y2

mean = 0  # 均值
std_dev = 0.04 # 标准差
num_samples = len(y1)  # 样本数
np.random.seed(2)
random_data1 = np.random.normal(mean, std_dev, num_samples)
random_data2 = np.random.normal(mean, std_dev, num_samples)

y1 += random_data1
y2 += random_data2

x = [i for i in range(1,len(result1)+1)]

mpl.rcParams['font.family'] = 'times new roman'

fig, ax = plt.subplots()

# 绘制折线图
ax.plot(x, y1, label='Momentum1')
ax.plot(x, y2, label='Momentum2')

# 划定 x 坐标范围内的色区
ax.axvline(x=18, color='black', linestyle='--',alpha=0.3)
ax.axvline(x=35 ,color='black',  linestyle='--',alpha=0.3)
ax.axvline(x=54, color='black',  linestyle='--',alpha=0.3)
ax.axvline(x=70, color='black',  linestyle='--',alpha=0.3)


# 添加标签和标题
plt.xticks(fontsize=12)
plt.yticks(fontsize=12)
ax.set_xlabel('Points',fontsize=14)
ax.set_ylabel('Momentum',fontsize=14)

# # 显示图例
# ax.legend()

# 显示图形
# # 绘制折线图
# plt.plot(x, y, label='折线图')
#

#
# 标注p1的特殊点
# 破发点
# special_points_x = [61, 148, 200, 210, 298]
special_points_x = [18,68,85]
special_points_y = []
for i in range(len(special_points_x)):
    special_points_y.append(y1[special_points_x[i]-1])
plt.scatter(special_points_x, special_points_y, color='red', label='P1-break_won')

# ace点
# special_points_x1 = [97, 105, 131, 228, 233, 265, 302, 324]
special_points_x = [15,58,80]
special_points_y = []
for i in range(len(special_points_x)):
    special_points_y.append(y1[special_points_x[i]-1])
plt.scatter(special_points_x, special_points_y, color='blue', label='P1-ace')

# special_points_x= [1,5,6,17,39,44,57,59,]
# special_points_y = []
# for i in range(len(special_points_x)):
#     special_points_y.append(y1[special_points_x[i] - 1])
# plt.scatter(special_points_x, special_points_y, color='green', label='p1-2-fault')



# 标注p2的特殊点
special_points_x = [61]
special_points_y = []
for i in range(len(special_points_x)):
    special_points_y.append(y2[special_points_x[i]-1])
plt.scatter(special_points_x, special_points_y, color='#5FFFCF', label='P2-break_won')

# ace点
# special_points_x1 = [97, 105, 131, 228, 233, 265, 302, 324]
special_points_x =[10,36,]
special_points_y = []
for i in range(len(special_points_x)):
    special_points_y.append(y2[special_points_x[i]-1])
plt.scatter(special_points_x, special_points_y, color='#8E07CC', label='P2-ace')

# special_points_x= [120]
# special_points_y = []
# for i in range(len(special_points_x)):
#     special_points_y.append(y2[special_points_x[i] ])
# plt.scatter(special_points_x, special_points_y, color='#C3D70C', label='p2-2-fault')


ax.legend(loc='lower right')
plt.savefig('fig2.png',dpi=700)
plt.show()

