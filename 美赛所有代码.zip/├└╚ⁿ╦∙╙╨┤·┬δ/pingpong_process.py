import pandas as pd
import numpy as np


def my_write(name,x):
    # 将两列数据组合成一个 DataFrame
    data = {name: x}
    df_new = pd.DataFrame(data)

    # 指定新Excel文件的路径
    new_excel_file_path = r"result.xlsx"

    # 使用 to_excel 方法将数据写入新的Excel文件
    df_new.to_excel(new_excel_file_path, index=False)

    print(f"数据已成功写入新的Excel文件: {new_excel_file_path}")
def my_write2(name1,x1,name2,x2):
    # 将两列数据组合成一个 DataFrame
    data = {name1: x1,name2:x2}
    df_new = pd.DataFrame(data)

    # 指定新Excel文件的路径
    new_excel_file_path = r"result.xlsx"

    # 使用 to_excel 方法将数据写入新的Excel文件
    df_new.to_excel(new_excel_file_path, index=False)

    print(f"数据已成功写入新的Excel文件: {new_excel_file_path}")

df = pd.read_excel(r"D:\桌面\乒乓球.xlsx")

game_id = df['回合'].to_numpy()
set_beg=[]

for i in range(len(game_id)):
    if game_id[i]!=game_id[i-1]:
        set_beg.append(i)

set_beg.append(len(game_id))

# # 连续得分
# lian=[]
vic = df['胜球id'].to_numpy()
# for i in range(1,len(set_beg)):
#     b = set_beg[i-1]
#     e=set_beg[i]
#
#     p1_temp=0
#     p2_temp = 0
#
#     lian.append(0)
#
#     for j in range(b+1,e):
#         if vic[j-1]==1:
#             p2_temp=0
#             p1_temp+=1
#         else:
#             p1_temp=0
#             p2_temp+=1
#
#         if p1_temp!=0:
#             lian.append(p1_temp)
#         else:
#             lian.append(-1*p2_temp)
# my_write('连续得分',lian)

# # 得分率
#
point_no = df['编号'].tolist()
#
# score_rate1 =[]
# score_rate2=[]
#
# s1=0
# s2=0
#
# for i in range(len(point_no)):
#     score_rate1.append(s1/point_no[i-1])
#     score_rate2.append(s2/point_no[i-1])
#
#     if vic[i]==1:
#         s1+=1
#     else:
#         s2+=1
# my_write2('1得分率',score_rate1,'2得分率',score_rate2)

# 失误率

# err_rate1=[]
# err_rate2=[]
# p1_unf_err = df['p1err'].tolist()
# p2_unf_err = df['p2err'].tolist()
# err1 = 0
# err2 = 0
#
# for i in range(len(point_no)):
#
#     err_rate1.append(err1/point_no[i-1])
#     err_rate2.append(err2/point_no[i-1])
#
#     if p1_unf_err[i]==1:
#         err1+=1
#     if p2_unf_err[i]==1:
#         err2+=1
#
#
#
# my_write2('err_rate1',err_rate1,'err_rate2',err_rate2)

# 破发率
#
# p1_break_pt = df['p1破发机会'].tolist()
# p2_break_pt = df['p2破发机会'].tolist()
# p1_break_pt_won = df['p1破发'].tolist()
# p2_break_pt_won = df['p2破发'].tolist()
#
# break_rate1 = []
# break_rate2 = []
#
# total_break1 = 0
# won_break1 = 0
# total_break2 = 0
# won_break2 = 0
#
# for i in range(0,len(point_no)):
#
#     if total_break1==0:
#         break_rate1.append(0)
#     else:
#         break_rate1.append(won_break1/total_break1)
#
#     if total_break2==0:
#         break_rate2.append(0)
#     else:
#         break_rate2.append(won_break2/total_break2)
#
#     if p1_break_pt[i]==1:
#         total_break1+=1
#     if p2_break_pt[i]==1:
#         total_break2+=1
#
#     if p1_break_pt_won[i]==1:
#         won_break1+=1
#     if p2_break_pt_won[i]==1:
#         won_break2+=1
#
#
#
#
# my_write2('p1破发球率',break_rate1,'p2破发球率',break_rate2)

# ace率

# server = df['发球'].tolist()
# p1_ace = df['p1ace'].tolist()
# p2_ace = df['p2ace'].tolist()
#
# ace_rate1 = []
# ace_rate2 = []
#
# server1 = 0
# ace1 = 0
# server2 = 0
# ace2 = 0
# for i in range(len(point_no)):
#
#     if server1==0:
#         ace_rate1.append(0)
#     else:
#         ace_rate1.append(ace1/server1)
#     if server2==0:
#         ace_rate2.append(0)
#     else:
#         ace_rate2.append(ace2/server2)
#
#     if server[i]==1:
#         server1+=1
#     else:
#         server2+=1
#
#     if p1_ace[i]==1:
#         ace1+=1
#     if p2_ace[i]==1:
#         ace2+=1
#
#
#
# my_write2('p1-ace率',ace_rate1,'p2-ace率',ace_rate2)


# 网前得分率

p1_net_pt = df['p1主动进攻'].tolist()
p2_net_pt = df['p2主动进攻'].tolist()
p1_net_pt_won = df['p1主动成功'].tolist()
p2_net_pt_won = df['p2主动成功'].tolist()

net_rate1 = []
net_rate2 = []

total_net1 = 0
won_net1 = 0
total_net2 = 0
won_net2 = 0
for i in range(len(point_no)):

    if total_net1==0:
        net_rate1.append(0)
    else:
        net_rate1.append(won_net1/total_net1)

    if total_net2==0:
        net_rate2.append(0)
    else:
        net_rate2.append(won_net2/total_net2)

    if p1_net_pt[i]==1:
        total_net1+=1
    if p2_net_pt[i]==1:
        total_net2+=1

    if p1_net_pt_won[i]==1:
        won_net1+=1
    if p2_net_pt_won[i]==1:
        won_net2+=1




my_write2('p1网前得分率',net_rate1,'p2网前得分率',net_rate2)