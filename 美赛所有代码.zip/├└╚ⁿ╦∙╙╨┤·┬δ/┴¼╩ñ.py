import numpy as np
import pandas as pd
import numpy
from statsmodels.sandbox.stats.runs import runstest_1samp
l1=[]
l2=[]
l3=[]
l4=[]
l5=[]
count=0


from scipy.stats import chi2_contingency


def jianyan(id,type):
    global count

    excel_file_path = rf"D:\桌面\动能\Force_{id}.xlsx"
    df1 = pd.read_excel(excel_file_path)

    y1 = df1[f'Force{type}'].to_numpy()
    if type==1:
        y2 = df1[f'Force2'].to_numpy()
    else:
        y2 = df1['Force2'].to_numpy()
    y_means = np.mean(y1)

    high=[]

    for i in range(len(y1)):
        if y1[i]>y_means:
            high.append(i)


    df2 = pd.read_excel(rf"D:\桌面\每场比赛(连续)\2023-wimbledon-{id}_subset.xlsx")

    lian = df2[f'{type}连续得分'].to_numpy()
    lian_high=0
    lian_total=0

    for index, item in enumerate(lian):
        if item>=2:
            lian_total+=1
            if np.isin(index-1,high):
                lian_high+=1

    l1.append(lian_high/len(high))
    l2.append(lian_total/len(y1))

    l5.append(len(high)/len(y1))

    df3 = pd.read_excel(rf"D:\桌面\每场比赛\2023-wimbledon-{id}_t_subset.xlsx")

    vic = df3['point_victor'].to_numpy()

    vic_high = 0
    vic_total=0
    for index, item in enumerate(vic):
        if item==type:
            vic_total+=1
            if np.isin(index-1,high):
                vic_high+=1

    l3.append(lian_high/vic_high)
    l4.append(lian_total/vic_total)


id_set=[]

a = [13,14,15,16,17]
for item in a:
    for i in range(1,2**(17-item)+1):
        if i<10:
            temp = str(item)+'0'+str(i)
            id_set.append(temp)
        else:
            temp = str(item)+str(i)
            id_set.append(temp)
for id in id_set:
    jianyan(id,1)
    jianyan(id,2)


print(count/len(l1))
data = {'高势头连胜次数/高势头球数':l1,'连胜次数/总球数':l2,'高势头连胜次数/高势头胜球数':l3,'连胜次数/总胜球数':l4,'高势头比例':l5}
df_new = pd.DataFrame(data)

# 指定新Excel文件的路径
new_excel_file_path = rf"D:\桌面\动能\runs_suc_prob.xlsx"

# 使用 to_excel 方法将数据写入新的Excel文件
df_new.to_excel(new_excel_file_path, index=False)

print(f"数据已成功写入新的Excel文件: {new_excel_file_path}")








