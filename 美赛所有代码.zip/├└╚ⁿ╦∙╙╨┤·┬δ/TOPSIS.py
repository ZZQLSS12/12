import pandas as pd
import numpy as np


def topsis(normalized_matrix, weights):
    ideal_positive = np.max(normalized_matrix, axis=0)
    ideal_negative = np.min(normalized_matrix, axis=0)

    distance_positive = np.sqrt(np.sum(weights * (normalized_matrix - ideal_positive) ** 2, axis=1))
    distance_negative = np.sqrt(np.sum(weights * (normalized_matrix - ideal_negative) ** 2, axis=1))

    # weighted_matrix = normalized_matrix * weights
    #
    # # Step 3: 计算理想解和负理想解
    # ideal_positive = np.max(weighted_matrix, axis=0)
    # ideal_negative = np.min(weighted_matrix, axis=0)
    #
    # # Step 4: 计算到理想解和负理想解的距离
    # distance_positive = np.sqrt(np.sum((weighted_matrix - ideal_positive) ** 2, axis=1))
    # distance_negative = np.sqrt(np.sum((weighted_matrix - ideal_negative) ** 2, axis=1))

    topsis_scores = distance_negative / (distance_positive + distance_negative)
    return topsis_scores


def my_write(name, x):
    # 将两列数据组合成一个 DataFrame
    data = {name: x}
    df_new = pd.DataFrame(data)

    # 指定新Excel文件的路径
    new_excel_file_path = r"D:\桌面\result.xlsx"

    # 使用 to_excel 方法将数据写入新的Excel文件
    df_new.to_excel(new_excel_file_path, index=False)

    print(f"数据已成功写入新的Excel文件: {new_excel_file_path}")

def my_write2(name1,x1,name2,x2,id):
    # 将两列数据组合成一个 DataFrame
    data = {name1: x1,name2:x2}
    df_new = pd.DataFrame(data)

    # 指定新Excel文件的路径
    new_excel_file_path = rf"D:\桌面\动能\Force_{id}.xlsx"

    # 使用 to_excel 方法将数据写入新的Excel文件
    df_new.to_excel(new_excel_file_path, index=False)

    print(f"数据已成功写入新的Excel文件: {new_excel_file_path}")

weights = pd.read_excel(r"D:\桌面\weight.xlsx")



def lianxv(id):
    df = pd.read_excel(rf"D:\桌面\每场比赛(连续)\2023-wimbledon-{id}_subset.xlsx")
    column_labels = df.columns.to_numpy()
    column_labels = column_labels[1:]
    column_labels[0], column_labels[1] = column_labels[1], column_labels[0]

    data = []

    for label in column_labels:
        data.append(df[label].to_list())

    Data = np.array(data)

    # p1
    # 对于正向指标
    for i in range(0, len(Data), 2):
        x_min = np.min(Data[i]) - 0.0001
        x_max = np.max(Data[i]) + 0.0001
        min_max_normalized = (Data[i] - x_min) / (x_max - x_min)
        Data[i] = min_max_normalized
    # 对于负向指标
    for i in range(1, len(Data), 2):
        x_min = np.min(Data[i]) - 0.0001
        x_max = np.max(Data[i]) + 0.0001
        min_max_normalized = (x_max - Data[i]) / (x_max - x_min)
        Data[i] = min_max_normalized

    data1 = np.array(list(zip(*(Data.tolist()))))

    weight1 = np.array(weights['连续'].tolist())
    scores1 = topsis(data1, weight1)

    Data = np.array(data)

    # p2
    # 对于正向指标
    for i in range(1, len(Data), 2):
        x_min = np.min(Data[i]) - 0.0001
        x_max = np.max(Data[i]) + 0.0001
        min_max_normalized = (Data[i] - x_min) / (x_max - x_min)
        Data[i] = min_max_normalized
    # 对于负向指标
    for i in range(0, len(Data), 2):
        x_min = np.min(Data[i]) - 0.0001
        x_max = np.max(Data[i]) + 0.0001
        min_max_normalized = (x_max - Data[i]) / (x_max - x_min)
        Data[i] = min_max_normalized

    data2 = np.array(list(zip(*(Data.tolist()))))

    for i in range(0, len(weight1), 2):
        weight1[i], weight1[i + 1] = weight1[i + 1], weight1[i]
    scores2 = topsis(data2, weight1)

    return scores1, scores2

def lisan(id):
    df = pd.read_excel(rf"D:\桌面\每场比赛(离散)\2023-wimbledon-{id}_subset.xlsx")
    column_labels = df.columns.to_numpy()
    column_labels = column_labels[1:]
    column_labels[0], column_labels[1] = column_labels[1], column_labels[0]

    data = []

    for label in column_labels:
        data.append(df[label].to_list())

    Data = np.array(data).astype(float)

    # p1
    # 对于正向指标
    for i in range(0, len(Data), 2):
        x_min = np.min(Data[i]) - 0.0001
        x_max = np.max(Data[i]) + 0.0001
        min_max_normalized = (Data[i] - x_min) / (x_max - x_min)
        Data[i] = min_max_normalized
    # 对于负向指标
    for i in range(1, len(Data), 2):
        x_min = np.min(Data[i]) - 0.0001
        x_max = np.max(Data[i]) + 0.0001
        min_max_normalized = (x_max - Data[i]) / (x_max - x_min)
        Data[i] = min_max_normalized

    data1 = np.array(list(zip(*(Data.tolist()))))

    weight2 = np.array(weights['离散'].tolist()[0:8])
    scores1 = topsis(data1, weight2)

    Data = np.array(data).astype(float)

    # p2
    # 对于正向指标
    for i in range(1, len(Data), 2):
        x_min = np.min(Data[i]) - 0.0001
        x_max = np.max(Data[i]) + 0.0001
        min_max_normalized = (Data[i] - x_min) / (x_max - x_min)
        Data[i] = min_max_normalized
    # 对于负向指标
    for i in range(0, len(Data), 2):
        x_min = np.min(Data[i]) - 0.0001
        x_max = np.max(Data[i]) + 0.0001
        min_max_normalized = (x_max - Data[i]) / (x_max - x_min)
        Data[i] = min_max_normalized

    data2 = np.array(list(zip(*(Data.tolist()))))

    for i in range(0, len(weight2), 2):
        weight2[i], weight2[i + 1] = weight2[i + 1], weight2[i]
    scores2 = topsis(data2, weight2)

    return scores1, scores2


id_set=[]

a = [13,14,15,16,17]
for item in a:
    for i in range(1,2**(17-item)+1):
        if i<10:
            temp = str(item)+'0'+str(i)
            id_set.append(temp)
        else:
            temp = str(item)+str(i)
            id_set.append(temp)
for id in id_set:
    f1,f2 = lianxv(id)
    f3,f4 = lisan(id)

    Force1 = f1+0.1*f3
    Force2 = f2+0.1*f4

    my_write2('Force1',Force1,'Force2',Force2,id)
# 权重
