import pandas as pd
import numpy as np

df = pd.read_excel(r'swing.xlsx')

swing = df['总波动'].to_numpy()
ans=[]
a=0
b=0
for it in swing:
    if it==0:
        ans.append('A')
        a+=1
    else:
        ans.append('B')
        b+=1


print(a)
print(b)
data = {'swing':ans}
df_new = pd.DataFrame(data)

# 指定新Excel文件的路径
new_excel_file_path = rf"swing_class.xlsx"

# 使用 to_excel 方法将数据写入新的Excel文件
df_new.to_excel(new_excel_file_path, index=False)

print(f"数据已成功写入新的Excel文件: {new_excel_file_path}")