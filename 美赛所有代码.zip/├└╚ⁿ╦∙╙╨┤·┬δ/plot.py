import matplotlib.pyplot as plt
import numpy as np
import matplotlib as mpl
import pandas as pd

mpl.rcParams['font.family'] = 'SimHei'
plt.rcParams['axes.unicode_minus'] = False


df1 = pd.read_excel(r"D:\桌面\每场比赛\2023-wimbledon-1301_t_subset.xlsx")
break2 = df1['p2_break_pt_won'].to_numpy()
ace2=df1['p2_ace'].to_numpy()
fault2= df1['p2_double_fault'].to_numpy()

# 检测特殊点
def jiance(list):
    ans=[]
    for i in range(len(list)):
        if list[i] == 1:
            ans.append(i)
    return ans





# 生成一些示例数据
id=1311

excel_file_path = rf"D:\桌面\动能\Force_{id}.xlsx"
df = pd.read_excel(excel_file_path)

# x = df['point'].to_numpy()
# y1 = df['1sum'].to_numpy()
# y2=df['2sum'].to_numpy()

y1 = df['Force1'].to_numpy()
y2 = df['Force2'].to_numpy()
x = [i for i in range(len(y1))]
mpl.rcParams['font.family'] = 'times new roman'

fig, ax = plt.subplots()

# 绘制折线图
ax.plot(x, y1, label='Momentum1')
ax.plot(x, y2, label='Momentum2')

# # 划定 x 坐标范围内的色区
# ax.axvline(x=44, color='black', linestyle='--',alpha=0.3)
# ax.axvline(x=138 ,color='black',  linestyle='--',alpha=0.3)
# ax.axvline(x=208, color='black',  linestyle='--',alpha=0.3)
# ax.axvline(x=272, color='black',  linestyle='--',alpha=0.3)
# # ax.axvline(x=333, color='black', linestyle='--',alpha=0.3)
#
#
# # 添加标签和标题
# plt.xticks(fontsize=12)
# plt.yticks(fontsize=12)
# ax.set_xlabel('Points',fontsize=14)
# ax.set_ylabel('Momentum',fontsize=14)
#
#
# # # 显示图例
# # ax.legend()
#
# # 显示图形
# # # 绘制折线图
# # plt.plot(x, y, label='折线图')
# #
#
#
# # 标注p1的特殊点
# # 破发点
# # special_points_x = [61, 148, 200, 210, 298]
# special_points_x = [61,298]
# special_points_y = []
# for i in range(len(special_points_x)):
#     special_points_y.append(y1[special_points_x[i] - 2])
# plt.scatter(special_points_x, special_points_y, color='red', label='P1-break_won')
#
# # ace点
# # special_points_x1 = [97, 105, 131, 228, 233, 265, 302, 324]
# special_points_x = [105, 131]
# special_points_y = []
# for i in range(len(special_points_x)):
#     special_points_y.append(y1[special_points_x[i] - 2])
# plt.scatter(special_points_x, special_points_y, color='blue', label='P1-ace')
#
# special_points_x= [62]
# special_points_y = []
# for i in range(len(special_points_x)):
#     special_points_y.append(y1[special_points_x[i] - 2])
# plt.scatter(special_points_x, special_points_y, color='green', label='P1-double_fault')
#
#
#
# # 标注p2的特殊点
# special_points_x = [15,67,252]
# special_points_y = []
# for i in range(len(special_points_x)):
#     special_points_y.append(y2[special_points_x[i] ])
# plt.scatter(special_points_x, special_points_y, color='#5FFFCF', label='P2-break_won')
#
# # ace点
# # special_points_x1 = [97, 105, 131, 228, 233, 265, 302, 324]
# special_points_x =[21]
# special_points_y = []
# for i in range(len(special_points_x)):
#     special_points_y.append(y2[special_points_x[i] ])
# plt.scatter(special_points_x, special_points_y, color='#8E07CC', label='P2-ace')
#
# special_points_x= [120]
# special_points_y = []
# for i in range(len(special_points_x)):
#     special_points_y.append(y2[special_points_x[i] ])
# plt.scatter(special_points_x, special_points_y, color='#C3D70C', label='P2-double_fault')


ax.legend(loc='lower right')
plt.savefig('fig1.png',dpi=700)
plt.show()




